from flask_wtf.csrf import CSRFProtect, CSRFError

csrf = CSRFProtect()